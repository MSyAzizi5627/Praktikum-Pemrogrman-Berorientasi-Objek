/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.service;

/**
 *
 * @author xtian
 */
import reservasi.model.PengurusOrmawa;
import reservasi.model.Reservasi;
import reservasi.notifikasi.Notifikator;
import reservasi.repository.ReservasiRepository;

public class ReservasiService {
    private final ReservasiRepository repository;
    private final PenjadwalanService penjadwalan;
    private final Notifikator notifikator;

    public ReservasiService(ReservasiRepository repository, PenjadwalanService penjadwalan,
                            Notifikator notifikator) {
        this.repository = repository;
        this.penjadwalan = penjadwalan;
        this.notifikator = notifikator;
    }

    // synchronized supaya cek bentrok + simpan tidak terpotong (cegah double booking)
    public synchronized Reservasi ajukan(PengurusOrmawa pengurus, Reservasi reservasi) {
        int peserta = reservasi.getKegiatan().getJumlahPeserta();
        if (!reservasi.getRuangan().validasiKapasitas(peserta)) {
            throw new IllegalArgumentException("Kapasitas tidak sesuai: " + peserta
                    + " peserta, kapasitas ruang " + reservasi.getRuangan().getKapasitas());
        }
        if (penjadwalan.cekBentrok(reservasi)) {
            throw new IllegalStateException("Jadwal bentrok dengan reservasi lain.");
        }
        pengurus.ajukan(reservasi);
        repository.simpan(reservasi);
        notifikator.kirim("Staf Sarpras", "Pengajuan baru: " + reservasi);
        return reservasi;
    }

    public synchronized void batalkan(PengurusOrmawa pengurus, Reservasi reservasi) {
        pengurus.batalkan(reservasi); // ubahStatus menolak jika sudah APPROVED/REJECTED
        repository.simpan(reservasi);
        notifikator.kirim(pengurus.getEmail(), "Reservasi #" + reservasi.getId() + " dibatalkan.");
    }
}
