/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.service;

/**
 *
 * @author xtian
 */
import reservasi.model.Reservasi;
import reservasi.model.StafKemahasiswaan;
import reservasi.model.StafSarpras;
import reservasi.notifikasi.Notifikator;
import reservasi.repository.ReservasiRepository;

public class PersetujuanService {
    private final ReservasiRepository repository;
    private final PenjadwalanService penjadwalan;
    private final Notifikator notifikator;

    public PersetujuanService(ReservasiRepository repository, PenjadwalanService penjadwalan,
                              Notifikator notifikator) {
        this.repository = repository;
        this.penjadwalan = penjadwalan;
        this.notifikator = notifikator;
    }

    public synchronized void verifikasi(StafSarpras staf, Reservasi reservasi,
                                        boolean setuju, String catatan) {
        if (setuju && penjadwalan.cekBentrok(reservasi)) {
            setuju = false;
            catatan = "Bentrok jadwal terdeteksi otomatis";
        }
        staf.verifikasi(reservasi, setuju, catatan);
        repository.simpan(reservasi);
        notifikator.kirim(reservasi.getPengaju().getEmail(),
                "Status #" + reservasi.getId() + ": " + reservasi.getStatus());
        if (setuju) {
            notifikator.kirim("Staf Kemahasiswaan", "Menunggu persetujuan akhir: " + reservasi);
        }
    }

    public synchronized void setujuiAkhir(StafKemahasiswaan staf, Reservasi reservasi,
                                          boolean setuju, String catatan) {
        if (setuju && penjadwalan.cekBentrok(reservasi)) {
            setuju = false;
            catatan = "Bentrok jadwal terdeteksi otomatis";
        }
        staf.setujuiAkhir(reservasi, setuju, catatan);
        repository.simpan(reservasi);
        notifikator.kirim(reservasi.getPengaju().getEmail(),
                "Status #" + reservasi.getId() + ": " + reservasi.getStatus());
    }
}
