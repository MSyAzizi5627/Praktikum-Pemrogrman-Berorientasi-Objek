/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.service;

/**
 *
 * @author xtian
 */
import java.util.List;
import reservasi.model.Reservasi;
import reservasi.repository.ReservasiRepository;

public class PenjadwalanService {
    private final ReservasiRepository repository;

    public PenjadwalanService(ReservasiRepository repository) {
        this.repository = repository;
    }

    /** true jika ada reservasi aktif lain yang beririsan di ruang dan tanggal yang sama. */
    public boolean cekBentrok(Reservasi baru) {
        List<Reservasi> bentrok = repository.cariPadaJadwal(
                baru.getRuangan(), baru.getTanggal(), baru.getJamMulai(), baru.getJamSelesai());
        for (Reservasi r : bentrok) {
            if (r.getId() != baru.getId()) {
                return true;
            }
        }
        return false;
    }
}