/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.controller;

/**
 *
 * @author xtian
 */
import reservasi.model.PengurusOrmawa;
import reservasi.model.Reservasi;
import reservasi.service.ReservasiService;

public class ReservasiController {
    private final ReservasiService reservasiService;

    public ReservasiController(ReservasiService reservasiService) {
        this.reservasiService = reservasiService;
    }

    public void ajukan(PengurusOrmawa pengurus, Reservasi reservasi) {
        try {
            reservasiService.ajukan(pengurus, reservasi);
            System.out.println("Berhasil diajukan: " + reservasi);
        } catch (RuntimeException e) {
            System.out.println("Pengajuan gagal: " + e.getMessage());
        }
    }

    public void batalkan(PengurusOrmawa pengurus, Reservasi reservasi) {
        try {
            reservasiService.batalkan(pengurus, reservasi);
            System.out.println("Berhasil dibatalkan: " + reservasi);
        } catch (RuntimeException e) {
            System.out.println("Pembatalan gagal: " + e.getMessage());
        }
    }

    public void lihatStatus(Reservasi reservasi) {
        System.out.println(reservasi);
        reservasi.getRiwayat().forEach(r -> System.out.println("   " + r));
    }
}
