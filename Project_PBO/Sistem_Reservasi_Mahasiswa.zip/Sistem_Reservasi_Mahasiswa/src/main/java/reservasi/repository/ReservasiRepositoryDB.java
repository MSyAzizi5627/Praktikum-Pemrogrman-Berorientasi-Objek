/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package reservasi.repository;

/**
 *
 * @author xtian
 */
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import reservasi.model.Reservasi;
import reservasi.model.Ruangan;

// Implementasi sementara: penyimpanan di memori. Bisa diganti SQLite/JDBC nanti.
public class ReservasiRepositoryDB implements ReservasiRepository {
    private final Map<Integer, Reservasi> data = new LinkedHashMap<>();

    @Override
    public synchronized void simpan(Reservasi reservasi) {
        data.put(reservasi.getId(), reservasi);
    }

    @Override
    public synchronized List<Reservasi> cariPadaJadwal(Ruangan ruangan, LocalDate tanggal,
                                                       LocalTime mulai, LocalTime selesai) {
        List<Reservasi> hasil = new ArrayList<>();
        for (Reservasi r : data.values()) {
            boolean ruangSama = r.getRuangan().getKodeRuangan().equals(ruangan.getKodeRuangan());
            boolean tanggalSama = r.getTanggal().equals(tanggal);
            boolean beririsan = mulai.isBefore(r.getJamSelesai()) && selesai.isAfter(r.getJamMulai());
            if (r.aktif() && ruangSama && tanggalSama && beririsan) {
                hasil.add(r);
            }
        }
        return hasil;
    }

    @Override
    public synchronized Reservasi cariById(int id) { return data.get(id); }

    @Override
    public synchronized List<Reservasi> semua() { return new ArrayList<>(data.values()); }
}
