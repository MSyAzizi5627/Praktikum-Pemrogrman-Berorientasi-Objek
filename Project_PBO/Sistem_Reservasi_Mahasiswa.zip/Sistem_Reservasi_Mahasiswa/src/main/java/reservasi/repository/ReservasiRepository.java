/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package reservasi.repository;

/**
 *
 * @author xtian
 */
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import reservasi.model.Reservasi;
import reservasi.model.Ruangan;

public interface ReservasiRepository {
    void simpan(Reservasi reservasi);
    List<Reservasi> cariPadaJadwal(Ruangan ruangan, LocalDate tanggal, LocalTime mulai, LocalTime selesai);
    Reservasi cariById(int id);
    List<Reservasi> semua();
}
