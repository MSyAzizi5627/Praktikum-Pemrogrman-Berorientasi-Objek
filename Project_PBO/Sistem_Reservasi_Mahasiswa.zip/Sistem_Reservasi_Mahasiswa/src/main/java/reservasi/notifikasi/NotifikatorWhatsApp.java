/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.notifikasi;

/**
 *
 * @author xtian
 */
public class NotifikatorWhatsApp implements Notifikator {
    @Override
    public void kirim(String penerima, String pesan) {
        System.out.println("[WA -> " + penerima + "] " + pesan);
    }
}
