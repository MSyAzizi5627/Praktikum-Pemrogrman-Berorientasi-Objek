/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package reservasi.notifikasi;

/**
 *
 * @author xtian
 */
public interface Notifikator {
    void kirim(String penerima, String pesan);
}
