/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.ui;

/**
 *
 * @author xtian
 */
import java.time.LocalDate;
import java.time.LocalTime;
import reservasi.controller.ReservasiController;
import reservasi.model.*;
import reservasi.notifikasi.Notifikator;
import reservasi.notifikasi.NotifikatorEmail;
import reservasi.repository.ReservasiRepository;
import reservasi.repository.ReservasiRepositoryDB;
import reservasi.service.PenjadwalanService;
import reservasi.service.PersetujuanService;
import reservasi.service.ReservasiService;

public class Main {
    public static void main(String[] args) {
        // Infrastructure + service (ganti ke NotifikatorWhatsApp bila perlu)
        ReservasiRepository repo = new ReservasiRepositoryDB();
        Notifikator notif = new NotifikatorEmail();
        PenjadwalanService penjadwalan = new PenjadwalanService(repo);
        ReservasiService reservasiService = new ReservasiService(repo, penjadwalan, notif);
        PersetujuanService persetujuan = new PersetujuanService(repo, penjadwalan, notif);
        ReservasiController controller = new ReservasiController(reservasiService);

        // Data awal
        Ormawa bem = new Ormawa(1, "BEM Universitas");
        Ormawa himaTi = new Ormawa(2, "HIMA Teknik Informatika");
        PengurusOrmawa andi = new PengurusOrmawa(1, "Andi", "andi@bem.ac.id", bem);
        PengurusOrmawa budi = new PengurusOrmawa(2, "Budi", "budi@hima.ac.id", himaTi);
        StafSarpras sarpras = new StafSarpras(3, "Citra", "citra@untidar.ac.id");
        StafKemahasiswaan kemahasiswaan = new StafKemahasiswaan(4, "Dewi", "dewi@untidar.ac.id");

        Ruangan aula = new Aula("GKU-AULA", 500);
        Ruangan kelas = new RuangKelas("GKU-301", 40);

        Fasilitas proyektor = new Fasilitas("Proyektor", "Baik");
        Fasilitas sound = new Fasilitas("Sound System", "Baik");

        andi.login();
        sarpras.login();
        kemahasiswaan.login();

        LocalDate tgl = LocalDate.of(2026, 12, 5);

        System.out.println("\n=== 1. Pengajuan normal ===");
        Reservasi r1 = new Reservasi(new Kegiatan(1, "Seminar Nasional", bem, 300), aula, andi,
                tgl, LocalTime.of(8, 0), LocalTime.of(12, 0));
        r1.tambahFasilitas(new DetailFasilitas(proyektor, 2));
        r1.tambahFasilitas(new DetailFasilitas(sound, 1));
        controller.ajukan(andi, r1);

        System.out.println("\n=== 2. Pengajuan bentrok (harus gagal) ===");
        Reservasi r2 = new Reservasi(new Kegiatan(2, "Rapat Kerja", himaTi, 100), aula, budi,
                tgl, LocalTime.of(10, 0), LocalTime.of(13, 0));
        controller.ajukan(budi, r2);

        System.out.println("\n=== 3. Kapasitas melebihi (harus gagal) ===");
        Reservasi r3 = new Reservasi(new Kegiatan(3, "Workshop", himaTi, 80), kelas, budi,
                tgl, LocalTime.of(13, 0), LocalTime.of(15, 0));
        controller.ajukan(budi, r3);

        System.out.println("\n=== 4. Alur persetujuan berjenjang ===");
        persetujuan.verifikasi(sarpras, r1, true, "Ruang dan fasilitas tersedia");
        persetujuan.setujuiAkhir(kemahasiswaan, r1, true, "Kegiatan sesuai proker");
        controller.lihatStatus(r1);
        System.out.printf("Biaya operasional: Rp %,.0f%n", r1.hitungBiayaTotal());

        System.out.println("\n=== 5. Batalkan reservasi yang sudah APPROVED (harus gagal) ===");
        controller.batalkan(andi, r1);

        System.out.println("\n=== 6. Batalkan reservasi PENDING ===");
        Reservasi r4 = new Reservasi(new Kegiatan(4, "Diskusi Panel", himaTi, 30), kelas, budi,
                tgl, LocalTime.of(9, 0), LocalTime.of(11, 0));
        controller.ajukan(budi, r4);
        controller.batalkan(budi, r4);
        controller.lihatStatus(r4);
    }
}
