/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public class StafKemahasiswaan extends Pengguna implements Penyetuju {

    public StafKemahasiswaan(int id, String nama, String email) {
        super(id, nama, email);
    }

    @Override
    public String getPeran() { return "Staf Kemahasiswaan"; }

    @Override
    public void setujuiAkhir(Reservasi reservasi, boolean setuju, String catatan) {
        reservasi.ubahStatus(setuju ? StatusReservasi.APPROVED : StatusReservasi.REJECTED);
        reservasi.tambahRiwayat(new RiwayatPersetujuan("Kemahasiswaan",
                (setuju ? "DISETUJUI" : "DITOLAK") + " - " + catatan));
    }
}
