/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public class Kegiatan {
    private int idKegiatan;
    private String namaKegiatan;
    private Ormawa ormawa;
    private int jumlahPeserta;

    public Kegiatan(int idKegiatan, String namaKegiatan, Ormawa ormawa, int jumlahPeserta) {
        this.idKegiatan = idKegiatan;
        this.namaKegiatan = namaKegiatan;
        this.ormawa = ormawa;
        this.jumlahPeserta = jumlahPeserta;
    }

    public int getIdKegiatan() { return idKegiatan; }
    public String getNamaKegiatan() { return namaKegiatan; }
    public Ormawa getOrmawa() { return ormawa; }
    public int getJumlahPeserta() { return jumlahPeserta; }
}
