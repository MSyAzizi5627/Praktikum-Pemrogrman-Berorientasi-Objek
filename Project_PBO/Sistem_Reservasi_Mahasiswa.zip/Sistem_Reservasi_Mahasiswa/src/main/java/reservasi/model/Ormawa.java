/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public class Ormawa {
    private int idOrmawa;
    private String namaOrmawa;

    public Ormawa(int idOrmawa, String namaOrmawa) {
        this.idOrmawa = idOrmawa;
        this.namaOrmawa = namaOrmawa;
    }

    public int getIdOrmawa() { return idOrmawa; }
    public String getNamaOrmawa() { return namaOrmawa; }
}
