/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public interface Pengaju {
    void ajukan(Reservasi reservasi);
    void batalkan(Reservasi reservasi);
}