/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public interface Verifikator {
    void verifikasi(Reservasi reservasi, boolean setuju, String catatan);
}
