/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Reservasi {
    private static int counter = 0;

    private final int id;
    private LocalDate tanggal;
    private LocalTime jamMulai;
    private LocalTime jamSelesai;
    private StatusReservasi status;

    private Kegiatan kegiatan;
    private Ruangan ruangan;
    private PengurusOrmawa pengaju;
    private List<DetailFasilitas> daftarFasilitas = new ArrayList<>();
    private List<RiwayatPersetujuan> riwayat = new ArrayList<>();

    public Reservasi(Kegiatan kegiatan, Ruangan ruangan, PengurusOrmawa pengaju,
                     LocalDate tanggal, LocalTime jamMulai, LocalTime jamSelesai) {
        if (!jamMulai.isBefore(jamSelesai)) {
            throw new IllegalArgumentException("Jam mulai harus sebelum jam selesai.");
        }
        this.id = ++counter;
        this.kegiatan = kegiatan;
        this.ruangan = ruangan;
        this.pengaju = pengaju;
        this.tanggal = tanggal;
        this.jamMulai = jamMulai;
        this.jamSelesai = jamSelesai;
        this.status = StatusReservasi.PENDING;
    }

    public void tambahFasilitas(DetailFasilitas detail) { daftarFasilitas.add(detail); }
    public void tambahRiwayat(RiwayatPersetujuan r) { riwayat.add(r); }

    public void ubahStatus(StatusReservasi baru) {
        boolean valid;
        switch (status) {
            case PENDING:
                valid = baru == StatusReservasi.VERIFIED_SARPRAS || baru == StatusReservasi.REJECTED
                        || baru == StatusReservasi.CANCELLED;
                break;
            case VERIFIED_SARPRAS:
                valid = baru == StatusReservasi.APPROVED || baru == StatusReservasi.REJECTED
                        || baru == StatusReservasi.CANCELLED;
                break;
            default:
                valid = false; // APPROVED, REJECTED, CANCELLED = status akhir
        }
        if (!valid) {
            throw new IllegalStateException("Status tidak bisa berubah dari " + status + " ke " + baru);
        }
        this.status = baru;
    }

    public boolean aktif() {
        return status == StatusReservasi.PENDING
                || status == StatusReservasi.VERIFIED_SARPRAS
                || status == StatusReservasi.APPROVED;
    }

    public int getDurasiJam() {
        return (int) Math.ceil(Duration.between(jamMulai, jamSelesai).toMinutes() / 60.0);
    }

    public double hitungBiayaTotal() { return ruangan.hitungBiaya(getDurasiJam()); }

    public int getId() { return id; }
    public LocalDate getTanggal() { return tanggal; }
    public LocalTime getJamMulai() { return jamMulai; }
    public LocalTime getJamSelesai() { return jamSelesai; }
    public StatusReservasi getStatus() { return status; }
    public Kegiatan getKegiatan() { return kegiatan; }
    public Ruangan getRuangan() { return ruangan; }
    public PengurusOrmawa getPengaju() { return pengaju; }
    public List<DetailFasilitas> getDaftarFasilitas() { return daftarFasilitas; }
    public List<RiwayatPersetujuan> getRiwayat() { return riwayat; }

    @Override
    public String toString() {
        return "Reservasi #" + id + " | " + kegiatan.getNamaKegiatan() + " | "
                + ruangan.getKodeRuangan() + " | " + tanggal + " " + jamMulai + "-" + jamSelesai
                + " | " + status;
    }
}
