/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public class PengurusOrmawa extends Pengguna implements Pengaju {
    private Ormawa ormawa;

    public PengurusOrmawa(int id, String nama, String email, Ormawa ormawa) {
        super(id, nama, email);
        this.ormawa = ormawa;
    }

    public Ormawa getOrmawa() { return ormawa; }

    @Override
    public String getPeran() { return "Pengurus Ormawa"; }

    @Override
    public void ajukan(Reservasi reservasi) {
        reservasi.tambahRiwayat(new RiwayatPersetujuan("Pengajuan", "DIAJUKAN oleh " + nama));
    }

    @Override
    public void batalkan(Reservasi reservasi) {
        reservasi.ubahStatus(StatusReservasi.CANCELLED);
        reservasi.tambahRiwayat(new RiwayatPersetujuan("Pembatalan", "DIBATALKAN oleh " + nama));
    }
}
