/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public abstract class Pengguna {
    protected int id;
    protected String nama;
    protected String email;

    public Pengguna(int id, String nama, String email) {
        this.id = id;
        this.nama = nama;
        this.email = email;
    }

    public void login() {
        System.out.println(nama + " login sebagai " + getPeran());
    }

    public abstract String getPeran();

    public int getId() { return id; }
    public String getNama() { return nama; }
    public String getEmail() { return email; }
}