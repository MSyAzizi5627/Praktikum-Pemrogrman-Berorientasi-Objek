/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public class Fasilitas {
    private String namaFasilitas;
    private String kondisi;

    public Fasilitas(String namaFasilitas, String kondisi) {
        this.namaFasilitas = namaFasilitas;
        this.kondisi = kondisi;
    }

    public String getNamaFasilitas() { return namaFasilitas; }
    public String getKondisi() { return kondisi; }
}
