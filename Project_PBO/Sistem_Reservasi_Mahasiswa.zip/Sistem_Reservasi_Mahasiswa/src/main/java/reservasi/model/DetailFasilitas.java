/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public class DetailFasilitas {
    private Fasilitas fasilitas;
    private int jumlah;

    public DetailFasilitas(Fasilitas fasilitas, int jumlah) {
        this.fasilitas = fasilitas;
        this.jumlah = jumlah;
    }

    public Fasilitas getFasilitas() { return fasilitas; }
    public int getJumlah() { return jumlah; }
}
