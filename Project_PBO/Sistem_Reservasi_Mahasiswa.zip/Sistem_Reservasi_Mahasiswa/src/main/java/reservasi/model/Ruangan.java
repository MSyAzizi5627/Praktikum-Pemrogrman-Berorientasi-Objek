/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */

public abstract class Ruangan {
    protected String kodeRuangan;
    protected int kapasitas;

    public Ruangan(String kodeRuangan, int kapasitas) {
        this.kodeRuangan = kodeRuangan;
        this.kapasitas = kapasitas;
    }

    public abstract boolean validasiKapasitas(int jumlahPeserta);
    public abstract double hitungBiaya(int durasiJam);

    public String getKodeRuangan() { return kodeRuangan; }
    public int getKapasitas() { return kapasitas; }
}