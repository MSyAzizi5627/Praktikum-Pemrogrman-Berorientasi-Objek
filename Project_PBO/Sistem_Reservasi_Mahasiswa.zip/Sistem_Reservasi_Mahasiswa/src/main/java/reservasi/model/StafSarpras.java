/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public class StafSarpras extends Pengguna implements Verifikator {

    public StafSarpras(int id, String nama, String email) {
        super(id, nama, email);
    }

    @Override
    public String getPeran() { return "Staf Sarpras"; }

    @Override
    public void verifikasi(Reservasi reservasi, boolean setuju, String catatan) {
        reservasi.ubahStatus(setuju ? StatusReservasi.VERIFIED_SARPRAS : StatusReservasi.REJECTED);
        reservasi.tambahRiwayat(new RiwayatPersetujuan("Sarpras",
                (setuju ? "DIVERIFIKASI" : "DITOLAK") + " - " + catatan));
    }
}
