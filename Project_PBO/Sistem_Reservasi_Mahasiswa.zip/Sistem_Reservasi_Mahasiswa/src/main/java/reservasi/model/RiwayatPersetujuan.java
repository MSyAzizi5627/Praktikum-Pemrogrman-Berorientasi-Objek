/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
import java.time.LocalDateTime;

public class RiwayatPersetujuan {
    private String tahap;
    private String keputusan;
    private LocalDateTime waktu;

    public RiwayatPersetujuan(String tahap, String keputusan) {
        this.tahap = tahap;
        this.keputusan = keputusan;
        this.waktu = LocalDateTime.now();
    }

    public String getTahap() { return tahap; }
    public String getKeputusan() { return keputusan; }
    public LocalDateTime getWaktu() { return waktu; }

    @Override
    public String toString() {
        return "[" + waktu.withNano(0) + "] " + tahap + ": " + keputusan;
    }
}
