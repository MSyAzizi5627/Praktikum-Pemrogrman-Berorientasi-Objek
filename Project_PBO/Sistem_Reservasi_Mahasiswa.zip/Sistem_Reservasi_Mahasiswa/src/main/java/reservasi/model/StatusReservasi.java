/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */
public enum StatusReservasi {
    PENDING, VERIFIED_SARPRAS, APPROVED, REJECTED, CANCELLED
}
