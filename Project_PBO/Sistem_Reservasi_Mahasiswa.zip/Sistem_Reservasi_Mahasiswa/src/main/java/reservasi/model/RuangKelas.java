/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reservasi.model;

/**
 *
 * @author xtian
 */

public class RuangKelas extends Ruangan {
    private static final double TARIF_PER_JAM = 50_000;

    public RuangKelas(String kodeRuangan, int kapasitas) {
        super(kodeRuangan, kapasitas);
    }

    @Override
    public boolean validasiKapasitas(int jumlahPeserta) {
        return jumlahPeserta > 0 && jumlahPeserta <= kapasitas;
    }

    @Override
    public double hitungBiaya(int durasiJam) {
        return durasiJam * TARIF_PER_JAM;
    }
}
