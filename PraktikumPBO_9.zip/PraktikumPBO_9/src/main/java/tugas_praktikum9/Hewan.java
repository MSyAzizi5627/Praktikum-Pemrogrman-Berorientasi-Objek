/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum9;

/**
 *
 * @author acer
 */
abstract class Hewan {
    // Metode abstrak (tanpa implementasi tubuh metode)
    abstract void suara();  
}
