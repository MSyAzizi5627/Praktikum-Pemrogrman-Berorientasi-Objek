/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum9;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        // Polimorfisme: membuat objek dari kelas turunan
        Hewan kucing = new Kucing();
        Hewan anjing = new Anjing();

        // Memanggil metode suara()
        kucing.suara();
        anjing.suara();
    }
}
