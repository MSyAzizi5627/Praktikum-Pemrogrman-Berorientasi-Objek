/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum5;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        Mobil mobil = new Mobil();
        mobil.nama = "Sedan Sport";
        mobil.kecepatan = 220;
        mobil.jumlahRoda = 4;
        mobil.jumlahPintu = 2;

        System.out.println("=== INFO MOBIL (HIERARKI 3 LEVEL) ===");
        mobil.tampilkanInfo();

        System.out.println();

        SepedaMotor motor = new SepedaMotor();
        motor.nama = "Motor Trail";
        motor.kecepatan = 110;
        motor.jumlahRoda = 2;
        motor.jenisMesin = "4-tak";

        System.out.println("=== INFO MOTOR (HIERARKI 3 LEVEL) ===");
        motor.tampilkanInfo();
    }
}
