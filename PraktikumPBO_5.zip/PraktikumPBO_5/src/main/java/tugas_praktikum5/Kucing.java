/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum5;

/**
 *
 * @author acer
 */
public class Kucing extends Hewan {
    String warnaBulu;

    // Overriding metode suara
    @Override
    public void suara() {
        System.out.println("Suara      : Meong meong!");
    }

    // Overriding metode tampilkanInfo
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Warna Bulu : " + warnaBulu);
        suara(); // Memanggil suara khas kucing
    } 
}
