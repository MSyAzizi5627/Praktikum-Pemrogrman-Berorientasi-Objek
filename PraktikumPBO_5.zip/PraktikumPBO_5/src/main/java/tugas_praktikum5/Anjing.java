/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum5;

/**
 *
 * @author acer
 */
public class Anjing extends Hewan {
    String ras;

    // Overriding metode suara
    @Override
    public void suara() {
        System.out.println("Suara      : Guk guk!");
    }

    // Overriding metode tampilkanInfo
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Ras        : " + ras);
        suara(); // Memanggil suara khas anjing
    }
}
