/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum5;

/**
 *
 * @author acer
 */
public class MainHewan {
    public static void main(String[] args) {
        Kucing kucing = new Kucing();
        kucing.nama = "Artemis";
        kucing.jenis = "Mythic";
        kucing.warnaBulu = "Putih";

        System.out.println("=== DATA KUCING ===");
        kucing.tampilkanInfo();

        System.out.println();

        Anjing anjing = new Anjing();
        anjing.nama = "Cerberus";
        anjing.jenis = "Mitologi";
        anjing.ras = "Dewa Penjaga Neraka";

        System.out.println("=== DATA ANJING ===");
        anjing.tampilkanInfo();
    }
}
