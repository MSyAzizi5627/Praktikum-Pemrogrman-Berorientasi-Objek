/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaspraktikum10;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        // Objek Elektronik
        Pembayaran elektronik = new Elektronik();
        double hargaElektronik = 2500000.0;
        System.out.println("=== Produk Elektronik ===");
        System.out.println("Harga Barang: Rp " + hargaElektronik);
        System.out.println("Jumlah Pajak (10%): Rp " + elektronik.hitungPajak(hargaElektronik));
        
        System.out.println();

        // Objek Makanan
        Pembayaran makanan = new Makanan();
        double hargaMakanan = 50000.0;
        System.out.println("=== Produk Makanan ===");
        System.out.println("Harga Barang: Rp " + hargaMakanan);
        System.out.println("Jumlah Pajak (5%): Rp " + makanan.hitungPajak(hargaMakanan));
    }
}
