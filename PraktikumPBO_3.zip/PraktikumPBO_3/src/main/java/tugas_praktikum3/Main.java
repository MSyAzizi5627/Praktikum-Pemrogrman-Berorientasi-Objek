/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum3;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        Mobil mobil1 = new Mobil("Toyota", "Avanza", 2021, "Hitam");
        Mobil mobil2 = new Mobil("Honda", "Civic", 2023, "Putih");

        mobil1.displayInfo();
        mobil1.startEngine();
        
        mobil2.displayInfo();
        mobil2.startEngine();

        System.out.println("\n-- Setelah perubahan warna --");
        mobil1.setWarna("Merah");
        mobil1.displayInfo();
    }
}
