/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_Praktikum4;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        // 1. Buat objek Pekerja dan inisialisasi
        Pekerja pekerja1 = new Pekerja("Mefelz", 30, "Streamer", 20000000);

        // 2. Tampilkan informasi pekerja menggunakan toString()
        System.out.println("=== Informasi Awal ===");
        System.out.println(pekerja1.toString());

        // 3. Ubah nama menggunakan setter
        pekerja1.setNama("Mefelz Cloud");
        
        // Tampilkan ulang informasi pekerja
        System.out.println("\n=== Informasi Setelah Diubah ===");
        System.out.println(pekerja1.toString());
    }
}
