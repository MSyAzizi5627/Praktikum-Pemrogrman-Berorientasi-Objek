/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum4;

/**
 *
 * @author acer
 */
public class Praktikum_PBO4 {
    public static void main(String[] args) {
        // 1. Membuat objek dari class turunan (Mobil)
        Mobil mobilSaya = new Mobil("Honda Civic", 300, "Bensin", 4);

        System.out.println("=== Data Awal ===");
        
        // 2. Memanggil metode dari class induk (Kendaraan)
        mobilSaya.tampilkanInfoKendaraan();
        
        System.out.println("-----------------");
        
        // 3. Memanggil metode spesifik dari class turunan (Mobil)
        mobilSaya.tampilkanInfoMobil();

        System.out.println("\n=== Setelah Perubahan ===");
        
        // 4. Mengubah nama (private) menggunakan setter dari class induk
        mobilSaya.setNama("Honda Civic Type R");
        
        // 5. Mengubah jenis mesin (public) secara langsung (tanpa setter)
        mobilSaya.jenisMesin = "Bensin SuperSonic";
        
        // Menampilkan kembali data setelah diubah
        mobilSaya.tampilkanInfoKendaraan();
    }
} 
